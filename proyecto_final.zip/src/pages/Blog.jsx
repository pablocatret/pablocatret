import React from 'react';
function Blog() {
  return <div className='p-6 text-center text-xl'>Blog</div>;
}

export default Blog;